
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'defenderkhan',
  applicationName: 'velocity-fleet-apis',
  appUid: 'FFsGZB017M5Ftzt2sJ',
  orgUid: 'bc7d7940-a186-43b2-9c6e-a203f34b56ae',
  deploymentUid: '8f602298-e358-406d-8688-4262ece41be5',
  serviceName: 'velocity-fleet-apis',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'velocity-fleet-apis-prod-main', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}